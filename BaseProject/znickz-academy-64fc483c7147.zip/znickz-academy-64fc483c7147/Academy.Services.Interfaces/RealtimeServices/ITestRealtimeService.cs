﻿using System.Threading.Tasks;

namespace Academy.Services.Interfaces.RealtimeServices
{
    public interface ITestRealtimeService
    {
        Task Method();
    }
}
